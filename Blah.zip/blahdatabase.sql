CREATE DATABASE Blah;
GO

USE Blah;
GO

DROP TABLE IF EXISTS message;
DROP TABLE IF EXISTS post;
DROP TABLE IF EXISTS userAccount;
drop procedure if exists checkDuplicateEmail
drop procedure if exists registerUser
GO

CREATE TABLE userAccount (
  user_id INT IDENTITY(1,1) PRIMARY KEY,
  first_name NVARCHAR(20) NOT NULL,
  last_name NVARCHAR(20) NOT NULL,
  password VARCHAR(20) NOT NULL,
  email VARCHAR(50) NOT NULL UNIQUE
);
GO

CREATE TABLE message (
  chat_id INT IDENTITY(1,1) PRIMARY KEY,
  from_user INT NOT NULL,
  to_user INT NOT NULL,
  message VARCHAR(400) NOT NULL,
  chat_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_from_user FOREIGN KEY (from_user) REFERENCES userAccount (user_id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT fk_to_user FOREIGN KEY (to_user) REFERENCES userAccount (user_id) ON DELETE NO ACTION ON UPDATE NO ACTION
);
GO

CREATE TABLE post (
  post_id INT IDENTITY(1,1) PRIMARY KEY,
  user_id INT NOT NULL,
  body VARCHAR(500) NOT NULL,
  post_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_post_user FOREIGN KEY (user_id) REFERENCES userAccount (user_id) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

GO
CREATE PROCEDURE registerUser
    @first_name varchar(20),
    @last_name varchar(20),
    @password varchar(20),
    @email varchar(50)
AS
	BEGIN TRANSACTION	
    
	IF EXISTS (
        SELECT 1
        FROM userAccount
        WHERE email = @email
    )
    BEGIN
        ROLLBACK TRANSACTION;
		THROW 5000, 'Duplicated Email.', 1;
        RETURN;
    END
    
    INSERT INTO userAccount (first_name, last_name, password, email) 
    VALUES (@first_name, @last_name, @password, @email)
    
    COMMIT TRANSACTION;


CREATE PROCEDURE checkDuplicateEmail(@Email NVARCHAR(255))
AS
BEGIN
    -- Check if the email exists in the userAccount table
    IF EXISTS (SELECT 1 FROM userAccount WHERE email = @Email)
    BEGIN
        SELECT '10000' AS Message
    END
    ELSE
    BEGIN
        SELECT '20000' AS Message
    END
END

Go
Select * from userAccount

